from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.forms import UserCreationForm, PasswordChangeForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import update_session_auth_hash
from django.contrib import messages
from .models import Contato
from catalogo.models import Produto
from vendas.models import Pedido

def index(request):
    produtos_destaque = Produto.objects.all()[:3]
    avaliacoes = [
        {'cliente': 'Maria Silva', 'comentario': 'Produtos incríveis e entrega rápida!', 'nota': 5},
        {'cliente': 'João Pereira', 'comentario': 'Adorei a iniciativa sustentável.', 'nota': 4},
    ]
    return render(request, 'core/index.html', {
        'produtos': produtos_destaque,
        'avaliacoes': avaliacoes
    })

def quem_somos(request):
    desenvolvedores = ['Desenvolvedor Manus AI']
    return render(request, 'core/quem_somos.html', {'desenvolvedores': desenvolvedores})

def fale_conosco(request):
    if request.method == 'POST':
        nome = request.POST.get('nome')
        email = request.POST.get('email')
        assunto = request.POST.get('assunto')
        mensagem = request.POST.get('mensagem')
        Contato.objects.create(nome=nome, email=email, assunto=assunto, mensagem=mensagem)
        messages.success(request, 'Mensagem enviada com sucesso!')
        return redirect('index')
    return render(request, 'core/fale_conosco.html')

def cadastrar(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('index')
    else:
        form = UserCreationForm()
    return render(request, 'registration/cadastrar.html', {'form': form})

@login_required
def perfil(request):
    pedidos = Pedido.objects.filter(usuario=request.user).order_by('-data_pedido')
    return render(request, 'core/perfil.html', {'pedidos': pedidos})

@login_required
def alterar_senha(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Senha alterada com sucesso!')
            return redirect('perfil')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'registration/alterar_senha.html', {'form': form})

@login_required
def dashboard(request):
    if not request.user.is_staff:
        return redirect('index')
    
    stats = {
        'usuarios': 10,
        'produtos': Produto.objects.count(),
        'vendas': Pedido.objects.count(),
        'contatos': Contato.objects.count(),
    }
    return render(request, 'core/dashboard.html', {'stats': stats})
